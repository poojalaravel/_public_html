        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(url('dashboard')); ?>">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <?php if(Auth::User()->admin_type == 1): ?>
                <div class="sidebar-brand-text mx-3">Admin <sup></sup></div>
                <?php else: ?>
                <div class="sidebar-brand-text mx-3"><?php echo e(Auth::User()->name); ?> <sup></sup></div>
                <?php endif; ?>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li  <?php if(Request::is('dashboard')): ?> class="nav-item active" <?php else: ?> class="nav-item"  <?php endif; ?>>
                <a class="nav-link" href="<?php echo e(url('dashboard')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>
            <?php if(Auth::User()->admin_type == 1): ?>
            <li  <?php if(Request::is('productlist') || Request::is('addproduct')): ?> class="nav-item active" <?php else: ?> class="nav-item"  <?php endif; ?>>
                <a class="nav-link" href="<?php echo e(url('productlist')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Product List</span></a>
            </li>
            <li  <?php if(Request::is('accountlist') || Request::is('addaccount')): ?> class="nav-item active" <?php else: ?> class="nav-item"  <?php endif; ?>>
                <a class="nav-link" href="<?php echo e(url('accountlist')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Account List</span></a>
            </li>

            <li  <?php if(Request::is('userslist') || Request::is('userslist')): ?> class="nav-item active" <?php else: ?> class="nav-item"  <?php endif; ?>>
                <a class="nav-link" href="<?php echo e(url('userslist')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>User List</span></a>
            </li>
            <?php endif; ?>
          

        </ul>
        <!-- End of Sidebar -->
<?php /**PATH C:\wamp64\www\gameAdmins\resources\views/admin/sidebar.blade.php ENDPATH**/ ?>