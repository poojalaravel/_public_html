<?php $__env->startSection('content'); ?>

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
       <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                 <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                <div class="card-header py-3">
                        </div>
                    <!-- Page Heading -->

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">

                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Add Account</h6>
                        </div>

                        <div class="card-body">
                    <div class="row">

                    <div class="col-lg-12">
                        <div class="p-5">
                            <form class="user" action="<?php echo e(url('storeaccount')); ?>" Method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                              <input type="hidden" name="id" value="<?php echo e(isset($Account->id)? $Account->id:''); ?>">
                            <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="text" name="holder_name" class="form-control form-control-user" id="exampleFirstName"
                                            placeholder="Holder Name" value="<?php echo e(isset($Account->holder_name)? $Account->holder_name: ''); ?>">
                                    </div>
                                    
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="text" name="account_no" class="form-control form-control-user"
                                            id="exampleInputPassword" placeholder="Account Number" value="<?php echo e(isset($Account->account_no)? $Account->account_no: ''); ?>">
                                    </div>
                                    <div class="col-sm-6 mb-3 mb-sm-0 mt-3">
                                        <input type="text" name="ifsc_code"  class="form-control form-control-user"
                                            id="exampleRepeatPassword" placeholder="IFSC Code" value="<?php echo e(isset($Account->ifsc_code)? $Account->ifsc_code: ''); ?>">
                                    </div>
                                    
                                    
                                    <div class="col-sm-6 mb-3 mb-sm-0 mt-3">
                                        <input type="text" name="bank_name" class="form-control form-control-user" id="exampleLastName"
                                            placeholder="Bank Name"  value="<?php echo e(isset($Account->bank_name)? $Account->bank_name: ''); ?>">
                                    </div>
                                    <div class="col-sm-6 mb-3 mb-sm-0 mt-3">
                                        <input type="text" name="upi" class="form-control form-control-user" id="exampleLastName"
                                            placeholder="UPI Id"  value="<?php echo e(isset($Account->upi)? $Account->upi: ''); ?>">
                                    </div>
                                </div>
                               
                               
                                <button class="btn btn-primary btn-user float-right" type="submit">
                                    Submit
                                </button>
                            </form>

                        </div>
                    </div>
                </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\multi-authentication\resources\views/admin/add-account-details.blade.php ENDPATH**/ ?>